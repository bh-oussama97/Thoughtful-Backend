export const environment = {
  production: true,
  anthropicApiKey: 'YOUR_ANTHROPIC_API_KEY_HERE'
};
