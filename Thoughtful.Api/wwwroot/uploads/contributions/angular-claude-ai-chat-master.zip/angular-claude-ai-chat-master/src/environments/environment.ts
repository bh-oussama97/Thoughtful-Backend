export const environment = {
  production: false,
  anthropicApiKey: 'YOUR_ANTHROPIC_API_KEY_HERE'
};
